
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maidocaffe.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MaidoCaffeModSounds {
	public static Map<ResourceLocation, SoundEvent> REGISTRY = new HashMap<>();
	static {
		REGISTRY.put(new ResourceLocation("maido_caffe", "maido_binding_effect"),
				new SoundEvent(new ResourceLocation("maido_caffe", "maido_binding_effect")));
		REGISTRY.put(new ResourceLocation("maido_caffe", "maido_fire_effect"),
				new SoundEvent(new ResourceLocation("maido_caffe", "maido_fire_effect")));
		REGISTRY.put(new ResourceLocation("maido_caffe", "maido_tp_effect"), new SoundEvent(new ResourceLocation("maido_caffe", "maido_tp_effect")));
	}

	@SubscribeEvent
	public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
		for (Map.Entry<ResourceLocation, SoundEvent> sound : REGISTRY.entrySet())
			event.getRegistry().register(sound.getValue().setRegistryName(sound.getKey()));
	}
}
