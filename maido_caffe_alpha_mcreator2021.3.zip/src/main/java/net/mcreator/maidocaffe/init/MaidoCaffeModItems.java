
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maidocaffe.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.maidocaffe.item.MaidoCaffeBottleNeedleItem;
import net.mcreator.maidocaffe.item.MaidoCaffeBottleBloodItem;
import net.mcreator.maidocaffe.item.MaidoBindingContractItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MaidoCaffeModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item MAIDO_LEILA = register(
			new SpawnEggItem(MaidoCaffeModEntities.MAIDO_LEILA, -16777216, -26215, new Item.Properties().tab(MaidoCaffeModTabs.TAB_MAIDO_CAFFE_TAB))
					.setRegistryName("maido_leila_spawn_egg"));
	public static final Item MAIDO_BINDING_CONTRACT = register(new MaidoBindingContractItem());
	public static final Item MAIDO_CAFFE_BOTTLE_NEEDLE = register(new MaidoCaffeBottleNeedleItem());
	public static final Item MAIDO_CAFFE_BOTTLE_BLOOD = register(new MaidoCaffeBottleBloodItem());
	public static final Item MAIDO_CAFFE_SPAWN_BLOCK = register(MaidoCaffeModBlocks.MAIDO_CAFFE_SPAWN_BLOCK, MaidoCaffeModTabs.TAB_MAIDO_CAFFE_TAB);

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
