
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maidocaffe.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.maidocaffe.client.renderer.MaidoLeilaRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MaidoCaffeModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MaidoCaffeModEntities.MAIDO_LEILA, MaidoLeilaRenderer::new);
	}
}
