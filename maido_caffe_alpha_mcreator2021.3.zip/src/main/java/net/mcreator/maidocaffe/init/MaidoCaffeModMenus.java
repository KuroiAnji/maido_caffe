
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maidocaffe.init;

import net.minecraftforge.fmllegacy.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.maidocaffe.world.inventory.MaidoWaypointSetGUIMenu;
import net.mcreator.maidocaffe.world.inventory.MaidoWaypointInfoGUIMenu;
import net.mcreator.maidocaffe.world.inventory.MaidoWPListMenu;
import net.mcreator.maidocaffe.world.inventory.MaidoWPListEditMenu;
import net.mcreator.maidocaffe.world.inventory.MaidoGUIMenu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MaidoCaffeModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<MaidoGUIMenu> MAIDO_GUI = register("maido_gui", (id, inv, extraData) -> new MaidoGUIMenu(id, inv, extraData));
	public static final MenuType<MaidoWaypointSetGUIMenu> MAIDO_WAYPOINT_SET_GUI = register("maido_waypoint_set_gui",
			(id, inv, extraData) -> new MaidoWaypointSetGUIMenu(id, inv, extraData));
	public static final MenuType<MaidoWaypointInfoGUIMenu> MAIDO_WAYPOINT_INFO_GUI = register("maido_waypoint_info_gui",
			(id, inv, extraData) -> new MaidoWaypointInfoGUIMenu(id, inv, extraData));
	public static final MenuType<MaidoWPListMenu> MAIDO_WP_LIST = register("maido_wp_list",
			(id, inv, extraData) -> new MaidoWPListMenu(id, inv, extraData));
	public static final MenuType<MaidoWPListEditMenu> MAIDO_WP_LIST_EDIT = register("maido_wp_list_edit",
			(id, inv, extraData) -> new MaidoWPListEditMenu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
