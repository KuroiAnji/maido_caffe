
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maidocaffe.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.maidocaffe.client.gui.MaidoWaypointSetGUIScreen;
import net.mcreator.maidocaffe.client.gui.MaidoWaypointInfoGUIScreen;
import net.mcreator.maidocaffe.client.gui.MaidoWPListScreen;
import net.mcreator.maidocaffe.client.gui.MaidoWPListEditScreen;
import net.mcreator.maidocaffe.client.gui.MaidoGUIScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MaidoCaffeModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(MaidoCaffeModMenus.MAIDO_GUI, MaidoGUIScreen::new);
			MenuScreens.register(MaidoCaffeModMenus.MAIDO_WAYPOINT_SET_GUI, MaidoWaypointSetGUIScreen::new);
			MenuScreens.register(MaidoCaffeModMenus.MAIDO_WAYPOINT_INFO_GUI, MaidoWaypointInfoGUIScreen::new);
			MenuScreens.register(MaidoCaffeModMenus.MAIDO_WP_LIST, MaidoWPListScreen::new);
			MenuScreens.register(MaidoCaffeModMenus.MAIDO_WP_LIST_EDIT, MaidoWPListEditScreen::new);
		});
	}
}
