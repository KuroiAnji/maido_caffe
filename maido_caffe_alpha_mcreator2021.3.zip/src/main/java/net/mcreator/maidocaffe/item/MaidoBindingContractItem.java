
package net.mcreator.maidocaffe.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import net.mcreator.maidocaffe.init.MaidoCaffeModTabs;

import java.util.List;

public class MaidoBindingContractItem extends Item {
	public MaidoBindingContractItem() {
		super(new Item.Properties().tab(MaidoCaffeModTabs.TAB_MAIDO_CAFFE_TAB).stacksTo(10).fireResistant().rarity(Rarity.UNCOMMON));
		setRegistryName("maido_binding_contract");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent("A contract that binds maids to a owner."));
	}
}
