
package net.mcreator.maidocaffe.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import net.mcreator.maidocaffe.procedures.MaidoBottleBloodProcedureProcedure;
import net.mcreator.maidocaffe.init.MaidoCaffeModTabs;

import java.util.List;

public class MaidoCaffeBottleNeedleItem extends Item {
	public MaidoCaffeBottleNeedleItem() {
		super(new Item.Properties().tab(MaidoCaffeModTabs.TAB_MAIDO_CAFFE_TAB).stacksTo(10).rarity(Rarity.COMMON));
		setRegistryName("maido_caffe_bottle_needle");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent("Empty bottle with a needle to help you fill it."));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		InteractionResult retval = super.useOn(context);
		MaidoBottleBloodProcedureProcedure.execute(context.getPlayer());
		return retval;
	}
}
