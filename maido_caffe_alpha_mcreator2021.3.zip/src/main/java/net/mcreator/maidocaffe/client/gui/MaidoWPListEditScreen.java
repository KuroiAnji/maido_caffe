
package net.mcreator.maidocaffe.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;

import net.mcreator.maidocaffe.world.inventory.MaidoWPListEditMenu;
import net.mcreator.maidocaffe.network.MaidoWPListEditButtonMessage;
import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;
import net.mcreator.maidocaffe.MaidoCaffeMod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class MaidoWPListEditScreen extends AbstractContainerScreen<MaidoWPListEditMenu> {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Checkbox MaidoWP1Del;
	Checkbox MaidoWP2Del;
	Checkbox MaidoWP3Del;
	Checkbox MaidoWP4Del;
	Checkbox MaidoWP5Del;
	Checkbox MaidoWP6Del;
	Checkbox MaidoWP7Del;
	Checkbox MaidoWP8Del;
	Checkbox MaidoWP9Del;
	Checkbox MaidoWP10Del;

	public MaidoWPListEditScreen(MaidoWPListEditMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 300;
		this.imageHeight = 240;
	}

	private static final ResourceLocation texture = new ResourceLocation("maido_caffe:textures/maido_wp_list_edit.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP1) + "", 12, 18, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP2) + "", 12, 38, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP3) + "", 12, 58, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP4) + "", 12, 78, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP5) + "", 12, 98, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP6) + "", 12, 118, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP7) + "", 12, 138, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP8) + "", 12, 158, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP9) + "", 12, 178, -10092442);
		this.font.draw(poseStack, "" + ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP10) + "", 12, 198, -10092442);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
		MaidoWP1Del = new Checkbox(this.leftPos + 262, this.topPos + 8, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP1Del", MaidoWP1Del);
		this.addRenderableWidget(MaidoWP1Del);
		MaidoWP2Del = new Checkbox(this.leftPos + 262, this.topPos + 28, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP2Del", MaidoWP2Del);
		this.addRenderableWidget(MaidoWP2Del);
		MaidoWP3Del = new Checkbox(this.leftPos + 262, this.topPos + 48, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP3Del", MaidoWP3Del);
		this.addRenderableWidget(MaidoWP3Del);
		MaidoWP4Del = new Checkbox(this.leftPos + 262, this.topPos + 68, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP4Del", MaidoWP4Del);
		this.addRenderableWidget(MaidoWP4Del);
		MaidoWP5Del = new Checkbox(this.leftPos + 262, this.topPos + 88, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP5Del", MaidoWP5Del);
		this.addRenderableWidget(MaidoWP5Del);
		MaidoWP6Del = new Checkbox(this.leftPos + 262, this.topPos + 108, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP6Del", MaidoWP6Del);
		this.addRenderableWidget(MaidoWP6Del);
		MaidoWP7Del = new Checkbox(this.leftPos + 262, this.topPos + 128, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP7Del", MaidoWP7Del);
		this.addRenderableWidget(MaidoWP7Del);
		MaidoWP8Del = new Checkbox(this.leftPos + 262, this.topPos + 148, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP8Del", MaidoWP8Del);
		this.addRenderableWidget(MaidoWP8Del);
		MaidoWP9Del = new Checkbox(this.leftPos + 262, this.topPos + 168, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP9Del", MaidoWP9Del);
		this.addRenderableWidget(MaidoWP9Del);
		MaidoWP10Del = new Checkbox(this.leftPos + 262, this.topPos + 188, 150, 20, new TextComponent(""), false);
		MaidoWPListEditMenu.guistate.put("checkbox:MaidoWP10Del", MaidoWP10Del);
		this.addRenderableWidget(MaidoWP10Del);
		this.addRenderableWidget(new Button(this.leftPos + 149, this.topPos + 216, 56, 20, new TextComponent("Delete"), e -> {
			if (true) {
				MaidoCaffeMod.PACKET_HANDLER.sendToServer(new MaidoWPListEditButtonMessage(0, x, y, z));
				MaidoWPListEditButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 212, this.topPos + 216, 56, 20, new TextComponent("Cancel"), e -> {
			if (true) {
				MaidoCaffeMod.PACKET_HANDLER.sendToServer(new MaidoWPListEditButtonMessage(1, x, y, z));
				MaidoWPListEditButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}));
	}
}
