package net.mcreator.maidocaffe.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.maidocaffe.entity.MaidoLeilaEntity;
import net.mcreator.maidocaffe.client.model.Modelmaido;

public class MaidoLeilaRenderer extends MobRenderer<MaidoLeilaEntity, Modelmaido<MaidoLeilaEntity>> {
	public MaidoLeilaRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelmaido(context.bakeLayer(Modelmaido.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(MaidoLeilaEntity entity) {
		return new ResourceLocation("maido_caffe:textures/maido_leila_skin.png");
	}
}
