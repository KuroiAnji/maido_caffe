package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.entity.Entity;

public class MaidoWanderAICondProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (entity.getPersistentData().getBoolean("tagMaidoMain") == false || entity.getPersistentData().getBoolean("tagMaidoFollow") == false) {
			return true;
		}
		return false;
	}
}
