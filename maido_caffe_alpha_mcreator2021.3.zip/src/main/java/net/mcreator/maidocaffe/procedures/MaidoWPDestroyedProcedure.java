package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoWPDestroyedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((new Object() {
			public String getValue(LevelAccessor world, BlockPos pos, String tag) {
				BlockEntity blockEntity = world.getBlockEntity(pos);
				if (blockEntity != null)
					return blockEntity.getTileData().getString(tag);
				return "";
			}
		}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 0") == false) {
			if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 1") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 2") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP2 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 3") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP3 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 4") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP4 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 5") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP5 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 6") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP6 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 7") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP7 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 8") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP8 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 9") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP9 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 10") == true) {
				{
					String _setval = "not set";
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP10 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWPLimit = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		}
	}
}
