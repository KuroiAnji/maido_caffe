package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.entity.Entity;

public class MaidoLeilaInitialSpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("tagMaidoNBT") != true) {
			entity.getPersistentData().putString("tagMaidoName", "Leila ?");
			entity.getPersistentData().putBoolean("tagMaidoFollow", (false));
			entity.getPersistentData().putBoolean("tagMaidoMain", (false));
			entity.getPersistentData().putBoolean("tagMaidoNBT", (true));
		}
	}
}
