package net.mcreator.maidocaffe.procedures;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoBStayDispProcedure {
	public static boolean execute() {
		if (MaidoCaffeModVariables.MaidoInfo.contains("follow:true") == true) {
			return true;
		}
		return false;
	}
}
