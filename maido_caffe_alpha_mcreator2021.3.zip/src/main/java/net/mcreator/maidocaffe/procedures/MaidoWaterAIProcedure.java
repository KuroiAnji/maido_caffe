package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.entity.Entity;

public class MaidoWaterAIProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (entity.isInWater() == true) {
			return true;
		}
		return false;
	}
}
