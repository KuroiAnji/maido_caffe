package net.mcreator.maidocaffe.procedures;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoBActivateDispProcedure {
	public static boolean execute() {
		if (MaidoCaffeModVariables.MaidoState == true) {
			return false;
		}
		return true;
	}
}
