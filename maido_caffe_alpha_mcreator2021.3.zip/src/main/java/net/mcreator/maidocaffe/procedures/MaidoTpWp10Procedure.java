package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoTpWp10Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		String maidoX = "";
		String maidoY = "";
		String maidoZ = "";
		String maidoWPPos = "";
		String maidoPosAll = "";
		String maidoCom = "";
		MaidoSetReposeProcedure.execute(world, x, y, z, entity);
		maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP10;
		maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 2, maidoPosAll.indexOf('y') - 1);
		maidoX = maidoWPPos;
		maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 2, maidoPosAll.indexOf('z') - 1);
		maidoY = maidoWPPos;
		maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 2);
		maidoZ = maidoWPPos;
		maidoWPPos = maidoX + " " + (new Object() {
			double convert(String s) {
				try {
					return Double.parseDouble(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert(maidoY) + 1) + maidoZ;
		maidoCom = "tp " + MaidoCaffeModVariables.MaidoUUID + maidoWPPos;
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands().performCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "",
					new TextComponent(""), _level.getServer(), null).withSuppressedOutput(), maidoCom);
	}
}
