package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.client.gui.components.Checkbox;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

import java.util.HashMap;

public class MaidoWPDeleteProcedureProcedure {
	public static void execute(LevelAccessor world, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		String maidoWPPos = "";
		String maidoPosAll = "";
		double maidoPosX = 0;
		double maidoPosY = 0;
		double maidoPosZ = 0;
		if ((guistate.containsKey("checkbox:MaidoWP1Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP1Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP1).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP1;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP1 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP2Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP2Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP2).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP2;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP2 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP3Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP3Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP3).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP3;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP3 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP4Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP4Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP4).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP4;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP4 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP5Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP5Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP5).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP5;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP5 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP6Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP6Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP6).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP6;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP6 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP7Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP7Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP7).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP7;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP7 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP8Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP8Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP8).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP8;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP8 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP9Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP9Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP9).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP9;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP9 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if ((guistate.containsKey("checkbox:MaidoWP10Del") ? ((Checkbox) guistate.get("checkbox:MaidoWP10Del")).selected() : false)
				&& ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP10).contains("not set") == false) {
			maidoPosAll = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP10;
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('x') + 3, maidoPosAll.indexOf('y') - 1);
			maidoPosX = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('y') + 3, maidoPosAll.indexOf('z') - 1);
			maidoPosY = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			maidoWPPos = maidoPosAll.substring(maidoPosAll.indexOf('z') + 3);
			maidoPosZ = new Object() {
				double convert(String s) {
					try {
						return Double.parseDouble(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert(maidoWPPos);
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putString("tagMaidoWPSet", "wp: 0");
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			if (!world.isClientSide()) {
				BlockPos _bp = new BlockPos((int) maidoPosX, (int) maidoPosY, (int) maidoPosZ);
				BlockEntity _blockEntity = world.getBlockEntity(_bp);
				BlockState _bs = world.getBlockState(_bp);
				if (_blockEntity != null)
					_blockEntity.getTileData().putBoolean("tagMaidoWPActive", (false));
				if (world instanceof Level _level)
					_level.sendBlockUpdated(_bp, _bs, _bs, 3);
			}
			{
				String _setval = "not set";
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWP10 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWPLimit - 1;
				entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaidoWPLimit = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}
}
