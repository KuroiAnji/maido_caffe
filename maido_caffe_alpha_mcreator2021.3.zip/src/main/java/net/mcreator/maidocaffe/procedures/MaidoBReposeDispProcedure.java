package net.mcreator.maidocaffe.procedures;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoBReposeDispProcedure {
	public static boolean execute() {
		if (MaidoCaffeModVariables.MaidoInfo.contains("main:true") == true) {
			return true;
		}
		return false;
	}
}
