package net.mcreator.maidocaffe.procedures;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoBFollowDispProcedure {
	public static boolean execute() {
		if (MaidoCaffeModVariables.MaidoInfo.contains("follow:false") == true && MaidoCaffeModVariables.MaidoInfo.contains("main:true") == true) {
			return true;
		}
		return false;
	}
}
