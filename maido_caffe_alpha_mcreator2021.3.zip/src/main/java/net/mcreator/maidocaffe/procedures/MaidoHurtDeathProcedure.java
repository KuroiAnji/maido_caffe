package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.network.chat.TextComponent;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

public class MaidoHurtDeathProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 800) {
			if ((entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) == true) {
				if (sourceentity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("entity was tamed"), (false));
				if (entity.getPersistentData().getBoolean("tagMaidoMain") == true) {
					if (sourceentity instanceof Player _player && !_player.level.isClientSide())
						_player.displayClientMessage(new TextComponent("entity was set main"), (false));
					{
						double _setval = ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null)
								.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoMainLimit - 1;
						(entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null)
								.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.MaidoMainLimit = _setval;
									capability.syncPlayerVariables((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null));
								});
					}
				}
				{
					double _setval = ((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null)
							.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoOwnLimit - 1;
					(entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null)
							.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.MaidoOwnLimit = _setval;
								capability.syncPlayerVariables((entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null));
							});
				}
				entity.hurt(DamageSource.GENERIC, 1000);
				if (sourceentity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("Leila is dead"), (false));
			} else if ((entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) == false) {
				entity.hurt(DamageSource.GENERIC, 1000);
				if (sourceentity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("Leila is dead"), (false));
			}
		}
	}
}
