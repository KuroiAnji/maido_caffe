package net.mcreator.maidocaffe.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.client.gui.components.EditBox;

import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;

import java.util.HashMap;

public class MaidoWaypointSetProcedureProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		String localMaidoOldName = "";
		localMaidoOldName = new Object() {
			public String getValue(LevelAccessor world, BlockPos pos, String tag) {
				BlockEntity blockEntity = world.getBlockEntity(pos);
				if (blockEntity != null)
					return blockEntity.getTileData().getString(tag);
				return "";
			}
		}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPName");
		if (!world.isClientSide()) {
			BlockPos _bp = new BlockPos((int) x, (int) y, (int) z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null)
				_blockEntity.getTileData().putString("tagMaidoWPName",
						(guistate.containsKey("text:MaidoWPNameInput") ? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue() : ""));
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
		if (!world.isClientSide()) {
			BlockPos _bp = new BlockPos((int) x, (int) y, (int) z);
			BlockEntity _blockEntity = world.getBlockEntity(_bp);
			BlockState _bs = world.getBlockState(_bp);
			if (_blockEntity != null)
				_blockEntity.getTileData().putBoolean("tagMaidoWPNameSet", (true));
			if (world instanceof Level _level)
				_level.sendBlockUpdated(_bp, _bs, _bs, 3);
		}
		if ((new Object() {
			public String getValue(LevelAccessor world, BlockPos pos, String tag) {
				BlockEntity blockEntity = world.getBlockEntity(pos);
				if (blockEntity != null)
					return blockEntity.getTileData().getString(tag);
				return "";
			}
		}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 0") == false) {
			if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 1") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP1).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 2") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP2).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP2 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 3") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP3).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP3 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 4") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP4).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP4 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 5") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP5).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP5 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 6") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP6).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP6 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 7") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP7).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP7 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 8") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP8).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP8 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 9") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP9).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP9 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else if ((new Object() {
				public String getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getTileData().getString(tag);
					return "";
				}
			}.getValue(world, new BlockPos((int) x, (int) y, (int) z), "tagMaidoWPSet")).contains("wp: 10") == true) {
				{
					String _setval = ((entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoWP10).replace(
									localMaidoOldName,
									guistate.containsKey("text:MaidoWPNameInput")
											? ((EditBox) guistate.get("text:MaidoWPNameInput")).getValue()
											: "");
					entity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.MaidoWP10 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}
}
