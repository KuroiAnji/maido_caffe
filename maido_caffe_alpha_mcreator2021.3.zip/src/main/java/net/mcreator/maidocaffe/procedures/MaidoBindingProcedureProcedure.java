package net.mcreator.maidocaffe.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fmllegacy.network.NetworkHooks;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.InteractionHand;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.mcreator.maidocaffe.world.inventory.MaidoGUIMenu;
import net.mcreator.maidocaffe.network.MaidoCaffeModVariables;
import net.mcreator.maidocaffe.init.MaidoCaffeModParticles;
import net.mcreator.maidocaffe.init.MaidoCaffeModItems;

import java.util.Iterator;

import io.netty.buffer.Unpooled;

public class MaidoBindingProcedureProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		String localMaidoStringContent = "";
		if ((entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) == true
				&& sourceentity == (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null)) {
			MaidoCaffeModVariables.MaidoName = entity.getPersistentData().getString("tagMaidoName");
			localMaidoStringContent = "" + (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null);
			localMaidoStringContent = localMaidoStringContent.substring(localMaidoStringContent.indexOf('[') + 2,
					localMaidoStringContent.indexOf('/') - 1);
			MaidoCaffeModVariables.MaidoOwnerName = localMaidoStringContent;
			MaidoCaffeModVariables.MaidoUUID = entity.getStringUUID().toString();
			MaidoCaffeModVariables.MaidoInfo = "follow:" + entity.getPersistentData().getBoolean("tagMaidoFollow") + " main:"
					+ entity.getPersistentData().getBoolean("tagMaidoMain");
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					{
						if (sourceentity instanceof ServerPlayer _ent) {
							BlockPos _bpos = new BlockPos((int) x, (int) y, (int) z);
							NetworkHooks.openGui((ServerPlayer) _ent, new MenuProvider() {
								@Override
								public Component getDisplayName() {
									return new TextComponent("MaidoGUI");
								}

								@Override
								public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
									return new MaidoGUIMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
								}
							}, _bpos);
						}
					}
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 10);
		} else if ((entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) == true
				&& !(sourceentity == (entity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null))) {
			if (sourceentity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(new TextComponent("the maid is allready bound to another player"), (false));
		} else if ((entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) == false
				&& (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
						.getItem() == MaidoCaffeModItems.MAIDO_BINDING_CONTRACT) {
			if ((sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoMainLimit >= 2) {
				if (sourceentity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("You can have a maximum of 2 maids at the same time, please transfer one."),
							(false));
			} else if ((sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoOwnLimit >= 10) {
				if (sourceentity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("You have reached the maximum ammount of maid per player."), (false));
			} else if ((sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoOwnLimit < 10) {
				if (entity instanceof LivingEntity _entity)
					_entity.swing(InteractionHand.MAIN_HAND, true);
				if (sourceentity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(MaidoCaffeModItems.MAIDO_BINDING_CONTRACT);
					_setstack.setCount(
							(int) (((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getCount() - 1));
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof ServerPlayer _serverPlayer)
						_serverPlayer.getInventory().setChanged();
				}
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, new BlockPos((int) (entity.getX()), (int) (entity.getY()), (int) (entity.getZ())),
								ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("maido_caffe:maido_binding_effect")), SoundSource.AMBIENT,
								1, 1);
					} else {
						_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()),
								ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("maido_caffe:maido_binding_effect")), SoundSource.AMBIENT,
								1, 1, false);
					}
				}
				for (int index0 = 0; index0 < (int) (4); index0++) {
					if (world instanceof ServerLevel _level)
						_level.sendParticles(MaidoCaffeModParticles.MAIDO_BINDING_PARTICLE, (entity.getX()), (entity.getY()), (entity.getZ()), 4, 1,
								1, 1, 0.3);
				}
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private LevelAccessor world;

					public void start(LevelAccessor world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						if (entity instanceof TamableAnimal _toTame && sourceentity instanceof Player _owner)
							_toTame.tame(_owner);
						{
							double _setval = (sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoOwnLimit + 1;
							sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.MaidoOwnLimit = _setval;
								capability.syncPlayerVariables(sourceentity);
							});
						}
						if ((sourceentity instanceof ServerPlayer _plr && _plr.level instanceof ServerLevel
								? _plr.getAdvancements()
										.getOrStartProgress(
												_plr.server.getAdvancements().getAdvancement(new ResourceLocation("maido_caffe:maido_made_bound")))
										.isDone()
								: false) == false) {
							if (sourceentity instanceof ServerPlayer _player) {
								Advancement _adv = _player.server.getAdvancements()
										.getAdvancement(new ResourceLocation("maido_caffe:maido_made_bound"));
								AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
								if (!_ap.isDone()) {
									Iterator _iterator = _ap.getRemainingCriteria().iterator();
									while (_iterator.hasNext())
										_player.getAdvancements().award(_adv, (String) _iterator.next());
								}
							}
							if (sourceentity instanceof ServerPlayer _player) {
								Advancement _adv = _player.server.getAdvancements()
										.getAdvancement(new ResourceLocation("maido_caffe:maido_alpha_tester"));
								AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
								if (!_ap.isDone()) {
									Iterator _iterator = _ap.getRemainingCriteria().iterator();
									while (_iterator.hasNext())
										_player.getAdvancements().award(_adv, (String) _iterator.next());
								}
							}
						}
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, 80);
				if ((sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoMainLimit < 2) {
					entity.getPersistentData().putBoolean("tagMaidoFollow", (true));
					entity.getPersistentData().putBoolean("tagMaidoMain", (true));
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private LevelAccessor world;

						public void start(LevelAccessor world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							{
								double _setval = (sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new MaidoCaffeModVariables.PlayerVariables())).MaidoMainLimit + 1;
								sourceentity.getCapability(MaidoCaffeModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.MaidoMainLimit = _setval;
									capability.syncPlayerVariables(sourceentity);
								});
							}
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, 80);
				}
			}
		}
	}
}
